<?php
// $Id$

// used to transport merchant key hash
//include ($_SERVER['DOCUMENT_ROOT']."/mod/cclite/cclite-common.php") ;
$input = array('recent') ; // now via array 
$cclite = cclite_contents($input) ;
echo  $cclite ; 
?>

