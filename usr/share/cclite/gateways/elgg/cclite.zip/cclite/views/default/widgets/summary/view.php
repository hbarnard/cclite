<?php

include ($_SERVER['DOCUMENT_ROOT']."/mod/cclite/cclite-common.php") ; 
$input = array('summary') ; // now via array 
$cclite = cclite_contents($input) ;
echo  $cclite ; 
?>

